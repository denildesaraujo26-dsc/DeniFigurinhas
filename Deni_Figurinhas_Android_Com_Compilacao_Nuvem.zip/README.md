# Deni Figurinhas — Android

Projeto inicial Android em Kotlin, preparado para compilação na nuvem pelo GitHub Actions.

## APK pelo celular
1. Crie um repositório GitHub vazio chamado `DeniFigurinhas`.
2. Envie os arquivos e pastas deste projeto para a raiz do repositório (não envie o ZIP como um único arquivo).
3. Acesse a aba **Actions** do repositório.
4. Abra **Build Deni Figurinhas APK** e execute **Run workflow** se não iniciar automaticamente.
5. Quando terminar, abra a execução concluída e baixe o artefato `Deni-Figurinhas-APK`.
6. Extraia o artefato e instale `app-debug.apk` no Android.

## Integração
A integração usa o padrão de ContentProvider e intent documentado pelo projeto oficial WhatsApp Stickers. Teste em aparelho real com WhatsApp atualizado.

## Limites de arte
Figurinhas estáticas: WebP, 512 x 512 px, até 100 KB cada. Pacote: 3 a 30 figurinhas. Ícone de bandeja: 96 x 96 px, até 50 KB.

## Observação
Esta é uma base de desenvolvimento/teste, não um APK já compilado. A compilação e a importação devem ser verificadas em aparelho real antes de distribuir.
