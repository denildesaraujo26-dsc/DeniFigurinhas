package com.deni.figurinhas

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.content.res.AssetFileDescriptor
import java.io.File
import java.io.FileNotFoundException

class StickerContentProvider : ContentProvider() {
    private val packId = "deni_fofuras"
    private val stickerFiles = listOf("amor.webp", "fe.webp", "bom_dia.webp")
    private val metadataColumns = arrayOf(
        "identifier", "name", "publisher", "tray_image",
        "android_play_store_link", "ios_app_store_link",
        "publisher_email", "publisher_website", "privacy_policy_website",
        "license_agreement_website", "image_data_version", "avoid_cache",
        "animated_sticker_pack"
    )

    override fun onCreate(): Boolean = true

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor {
        val parts = uri.pathSegments
        return when {
            parts.size == 1 && parts[0] == "metadata" -> metadataCursor()
            parts.size == 2 && parts[0] == "metadata" && parts[1] == packId -> metadataCursor()
            parts.size == 2 && parts[0] == "stickers" && parts[1] == packId -> stickerCursor()
            else -> MatrixCursor(arrayOf("_id"))
        }
    }

    private fun metadataCursor() = MatrixCursor(metadataColumns).apply {
        addRow(arrayOf(
            packId, "Deni Figurinhas", "Deni", "tray.webp",
            "", "", "", "", "", "", "1", 0, 0
        ))
    }

    private fun stickerCursor() = MatrixCursor(arrayOf("identifier", "emoji", "accessibility_text")).apply {
        addRow(arrayOf("amor.webp", "💕", "Eu te amo"))
        addRow(arrayOf("fe.webp", "🙏", "Deus é bom"))
        addRow(arrayOf("bom_dia.webp", "🌸", "Bom dia"))
    }

    override fun getType(uri: Uri): String = when {
        uri.pathSegments.firstOrNull() == "stickers_asset" -> "image/webp"
        else -> "vnd.android.cursor.dir/vnd.com.deni.figurinhas.sticker"
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor {
        val parts = uri.pathSegments
        if (parts.size != 3 || parts[0] != "stickers_asset" || parts[1] != packId ||
            parts[2] !in stickerFiles && parts[2] != "tray.webp") {
            throw FileNotFoundException("Figurinha não encontrada")
        }
        val fileName = parts[2]
        val cached = File(context!!.cacheDir, fileName)
        if (!cached.exists()) {
            context!!.assets.open(fileName).use { input ->
                cached.outputStream().use { output -> input.copyTo(output) }
            }
        }
        val pfd = ParcelFileDescriptor.open(cached, ParcelFileDescriptor.MODE_READ_ONLY)
        return AssetFileDescriptor(pfd, 0, cached.length())
    }

    override fun insert(uri: Uri, values: ContentValues?) = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0
}
