package com.deni.figurinhas

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val authority = "com.deni.figurinhas.stickercontentprovider"
    private val packId = "deni_fofuras"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(255, 247, 251)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 24)
        }
        scroll.addView(page)

        page.addView(TextView(this).apply {
            text = "Deni Figurinhas 🌷"
            textSize = 28f
            setTextColor(Color.rgb(125, 75, 112))
            gravity = Gravity.CENTER
        }, matchWrap())

        page.addView(TextView(this).apply {
            text = "Um cantinho cheio de carinho, fé e alegria"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 22)
        }, matchWrap())

        page.addView(Button(this).apply {
            text = "Adicionar pacote ao WhatsApp"
            setOnClickListener { addStickerPack() }
        }, matchWrap())

        page.addView(TextView(this).apply {
            text = "COLEÇÃO DE FIGURINHAS"
            textSize = 14f
            setTextColor(Color.rgb(125, 75, 112))
            setPadding(0, 26, 0, 12)
        }, matchWrap())

        val stickers = listOf(
            "amor.webp" to "💕  Amor e carinho",
            "fe.webp" to "🙏  Fé e gratidão",
            "bom_dia.webp" to "🌸  Bom dia"
        )
        stickers.forEach { (file, label) ->
            page.addView(TextView(this).apply {
                text = label
                textSize = 18f
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(Color.rgb(115, 75, 105))
                setBackgroundColor(Color.WHITE)
                setPadding(18, 20, 18, 20)
                elevation = 2f
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 10
            })
        }

        page.addView(TextView(this).apply {
            text = "Escolha “Adicionar pacote ao WhatsApp” e confirme a importação no WhatsApp."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 8)
        }, matchWrap())

        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun addStickerPack() {
        val intent = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
            putExtra("sticker_pack_id", packId)
            putExtra("sticker_pack_authority", authority)
            putExtra("sticker_pack_name", "Deni Figurinhas")
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir o WhatsApp. Verifique se ele está instalado e atualizado.", Toast.LENGTH_LONG).show()
        }
    }
}
